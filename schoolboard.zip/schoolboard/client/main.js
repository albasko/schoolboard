import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

import './main.html';

Template.homework_list.helpers({
	homework: function(){
		return Homework.find({});
	}
});
Template.homework_item.helpers({
	homework: function(){
		return Homework.find({});
	}
});

/////
	// template events 
/////

// Template.homework_item.events({
// 	"click .js-upvote":function(event){
		
// 	} 
// })

// Template.hamburger.events({
// 'click .button-collapse': function(event){
//     $('.button-collapse').sideNav();
// }
// })


// Template.hamburger.onRendered(function () {
// 	  $('.button-collapse').sideNav({
// 	  	closeOnClick: true
// 	  });
// });


$(document).ready(function(){
	$(".button-collapse").sideNav(
		);
	$('.modal-trigger').leanModal();
	$('select').material_select();
});

// $(document).ready(function(){
//     // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
//     $('.modal-trigger').leanModal();
//    });

// $(document).ready(function() {
//     $('select').material_select();
//   });
